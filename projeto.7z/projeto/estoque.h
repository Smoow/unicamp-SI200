#ifndef _ESTOQUE_H
#define _ESTOQUE_H

void alterar_estoque();
void exibir_estoque();

#endif
