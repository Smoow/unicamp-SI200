#ifndef _PEDIDOS_H
#define _PEDIDOS_H

void realizar_pedido();
void exibir_balanca();
void exibir_pedidos_realizados();

#endif
