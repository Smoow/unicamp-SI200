#ifndef _REGISTRO_H
#define _REGISTRO_H

void registrar_cliente();
void exibir_clientes_registrados();

#endif

